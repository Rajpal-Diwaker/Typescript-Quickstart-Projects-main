# Restful API Data Validation & Control

![N|Solid](https://lh3.googleusercontent.com/a-/AOh14GglnMoBPixoeH-IwaCWx7SpehtvYTPowns21fVO=s200-k-no-rp-mo)

This repository is a basic example of using various libraries to validate data that is passed to your api. Inside of the middleware folder, you can view each sample routes protection.

## License

MIT
