export interface IYupData {
    name: string;
    age: number;
    email?: string | undefined;
    website?: string | null | undefined;
    createdOn: Date;
}
